package com.aza.pa

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import androidx.annotation.NonNull
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.MethodChannel
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import java.io.ByteArrayOutputStream
import android.content.pm.PackageInfo

class MainActivity : FlutterActivity() {
    private val CHANNEL = "permission.analyzer/apps"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getInstalledApps" -> {
                        result.success(getInstalledApps())
                    }
                    "secureApp" -> {
                        val pkg = call.arguments as? String
                        if (pkg != null) secureApp(pkg)
                        result.success(null)
                    }
                    "scanFile" -> {
                        val filePath = call.argument<String>("filePath")
                        val infected = scanFile(filePath ?: "")
                        result.success(infected)
                    }
                    "uninstallApp" -> {
                        val pkg = call.argument<String>("packageName") ?: ""
                        uninstallApp(pkg)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun getInstalledApps(): List<Map<String, Any>> {
        val pm = packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val appList = mutableListOf<Map<String, Any>>()

        for (appInfo in packages) {
            if (appInfo.flags and ApplicationInfo.FLAG_SYSTEM == 0) {
                val name = pm.getApplicationLabel(appInfo).toString()
                val pkg = appInfo.packageName

                // Fetch permissions + flags
                val pkgInfo = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
                val perms = pkgInfo.requestedPermissions ?: arrayOf()
                val flags = pkgInfo.requestedPermissionsFlags ?: IntArray(perms.size)

                // Only keep the dangerous ones that are actually GRANTED
                val risky = perms.mapIndexedNotNull { i, perm ->
                    if (dangerousPermissions.contains(perm)
                        && (flags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED != 0)
                    ) perm else null
                }

                appList += mapOf(
                    "name" to name,
                    "package" to pkg,
                    "isRisky" to (risky.isNotEmpty()),
                    "icon" to drawableToBase64(pm.getApplicationIcon(appInfo)),
                    "riskyPermissions" to risky
                )
            }
        }
        return appList
    }


    private fun secureApp(packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    private fun scanFile(filePath: String): Boolean {
        // TODO: Integrate real AV SDK here or implement logic to check for virus.
        // For demonstration purposes, it just checks for file name
        return filePath.contains("malicious.apk") // Mock detection of a file with a name "malicious.apk"
    }

    private fun uninstallApp(packageName: String) {
        val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE).apply {
            data = Uri.parse("package:$packageName")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    private fun drawableToBase64(drawable: Drawable): String {
        return try {
            val bmp = if (drawable is BitmapDrawable) {
                drawable.bitmap
            } else {
                val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: 100
                val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: 100
                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
                    Canvas(it).apply {
                        drawable.setBounds(0, 0, it.width, it.height)
                        drawable.draw(this)
                    }
                }
            }
            ByteArrayOutputStream().use { stream ->
                bmp.compress(Bitmap.CompressFormat.PNG, 100, stream)
                Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            ""
        }
    }

    private val dangerousPermissions = listOf(
        "android.permission.READ_SMS",
        "android.permission.READ_CONTACTS",
        "android.permission.RECORD_AUDIO",
        "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.READ_CALL_LOG"
    )
}
