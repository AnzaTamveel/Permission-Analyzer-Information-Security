import 'package:flutter/material.dart';
import 'dart:async';
import 'main.dart'; // For AppInfo

/// A mock security scan service. In real world, hook into actual APIs.
Future<List<String>> runSecurityScan(List<AppInfo> apps) async {
  // Simulate network/process delay
  await Future.delayed(Duration(seconds: 3));
  // Return packages of apps flagged as "suspicious"
  return apps
      .where((app) => app.isRisky)
      .map((app) => app.name)
      .toList();
}

class SecurityToolsPage extends StatefulWidget {
  final List<AppInfo> allApps;
  const SecurityToolsPage({Key? key, required this.allApps}) : super(key: key);

  @override
  _SecurityToolsPageState createState() => _SecurityToolsPageState();
}

class _SecurityToolsPageState extends State<SecurityToolsPage> {
  bool _scanning = false;
  List<String> _issues = [];

  void _startScan() async {
    setState(() {
      _scanning = true;
      _issues.clear();
    });

    final results = await runSecurityScan(widget.allApps);

    setState(() {
      _scanning = false;
      _issues = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ElevatedButton.icon(
            onPressed: _scanning ? null : _startScan,
            icon: Icon(Icons.shield),
            label: Text(_scanning ? 'Scanning...' : 'Run Security Scan'),
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 14),
            ),
          ),
          SizedBox(height: 20),
          if (_scanning) ...[
            Center(child: CircularProgressIndicator()),
            SizedBox(height: 20),
            Text('Scanning installed apps for anomalies...', textAlign: TextAlign.center),
          ] else if (_issues.isEmpty) ...[
            Icon(Icons.check_circle, size: 80, color: Colors.greenAccent),
            SizedBox(height: 12),
            Text('No issues found!', textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
          ] else ...[
            Text('Potential Issues:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: _issues.length,
                itemBuilder: (_, idx) {
                  final name = _issues[idx];
                  return ListTile(
                    leading: Icon(Icons.warning, color: Colors.redAccent),
                    title: Text(name),
                    subtitle: Text('Potential malicious behavior detected'),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}
