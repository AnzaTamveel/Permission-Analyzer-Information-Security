import 'package:flutter/material.dart';
import 'package:palette_generator/palette_generator.dart';
import 'dart:convert';
import 'dart:math';
import 'main.dart' show AppInfo;

class RiskyAppsPage extends StatefulWidget {
  final List<AppInfo> riskyApps;
  const RiskyAppsPage({required this.riskyApps});

  @override
  _RiskyAppsPageState createState() => _RiskyAppsPageState();
}

class _RiskyAppsPageState extends State<RiskyAppsPage> {
  int selectedIndex = 0;
  late PageController _bottomController;
  Color dominantColor = Colors.black;
  Color blendedColor = Colors.black;

  @override
  void initState() {
    super.initState();
    _bottomController = PageController(viewportFraction: 0.25);
    if (widget.riskyApps.isNotEmpty) {
      _extractDominantColor(widget.riskyApps[0]);
    }
  }

  Future<void> _extractDominantColor(AppInfo app) async {
    if (app.iconBase64.isNotEmpty) {
      final image = MemoryImage(base64Decode(app.iconBase64));
      final palette = await PaletteGenerator.fromImageProvider(image);
      setState(() {
        dominantColor = palette.dominantColor?.color ?? Colors.cyanAccent;
        blendedColor = Color.alphaBlend(
          Colors.black.withOpacity(0.6),
          dominantColor,
        );
      });
    }
  }

  void _onAppSelected(int index) {
    setState(() => selectedIndex = index);
    _extractDominantColor(widget.riskyApps[index]);
  }

  @override
  Widget build(BuildContext context) {
    if (widget.riskyApps.isEmpty) {
      return Center(
        child: Text("No risky apps found", style: TextStyle(color: Colors.grey)),
      );
    }

    final selectedApp = widget.riskyApps[selectedIndex];

    return Column(
      children: [
        SizedBox(height: 20),
        // Top zoomed selected app
        Expanded(
          child: Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: LinearGradient(
                colors: [
                  blendedColor.withOpacity(0.2),
                  Colors.black.withOpacity(0.8),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: dominantColor.withOpacity(0.5),
                  blurRadius: 16,
                  spreadRadius: 2,
                  offset: Offset(0, 6),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  selectedApp.iconBase64.isNotEmpty
                      ? Image.memory(
                    base64Decode(selectedApp.iconBase64),
                    width: 80,
                    height: 80,
                  )
                      : Icon(
                    Icons.android,
                    color: Colors.cyanAccent,
                    size: 80,
                  ),
                  SizedBox(height: 24),
                  Text(
                    selectedApp.name,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 24),
                  // Circular risk indicator
                  RiskCircularIndicator(riskLevel: selectedApp.riskLevel, size: 120),
                ],
              ),
            ),
          ),
        ),

        // Bottom horizontal apps scroll
        SizedBox(
          height: 100,
          child: PageView.builder(
            controller: _bottomController,
            itemCount: widget.riskyApps.length,
            onPageChanged: _onAppSelected,
            itemBuilder: (context, index) {
              final app = widget.riskyApps[index];
              final isSelected = index == selectedIndex;
              return GestureDetector(
                onTap: () {
                  _bottomController.animateToPage(
                    index,
                    duration: Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                  _onAppSelected(index);
                },
                child: AnimatedScale(
                  scale: isSelected ? 1.15 : 0.9,
                  duration: Duration(milliseconds: 300),
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(
                        colors: [
                          blendedColor.withOpacity(0.15),
                          Colors.black.withOpacity(0.75),
                        ],
                      ),
                      boxShadow: isSelected
                          ? [
                        BoxShadow(
                          color: dominantColor.withOpacity(0.4),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ]
                          : [],
                    ),
                    child: Center(
                      child: app.iconBase64.isNotEmpty
                          ? Image.memory(
                        base64Decode(app.iconBase64),
                        width: isSelected ? 50 : 40,
                        height: isSelected ? 50 : 40,
                      )
                          : Icon(
                        Icons.android,
                        color: Colors.cyanAccent,
                        size: isSelected ? 50 : 40,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }
}

class RiskCircularIndicator extends StatelessWidget {
  final double riskLevel;
  final double size;
  const RiskCircularIndicator({required this.riskLevel, this.size = 100});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _RiskCirclePainter(riskLevel),
    );
  }
}

class _RiskCirclePainter extends CustomPainter {
  final double riskLevel;
  _RiskCirclePainter(this.riskLevel);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    const stroke = 6.0;

    // Background circle
    final bgPaint = Paint()
      ..color = Colors.grey.shade800
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    canvas.drawCircle(center, radius, bgPaint);

    // Risk arc
    final redPaint = Paint()
      ..shader = SweepGradient(
        colors: [Colors.redAccent.withOpacity(0.8), Colors.transparent],
        startAngle: -pi / 2,
        endAngle: -pi / 2 + 2 * pi * riskLevel,
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -pi / 2,
      2 * pi * riskLevel,
      false,
      redPaint,
    );

    // Safe arc
    final greenPaint = Paint()
      ..shader = SweepGradient(
        colors: [Colors.transparent, Colors.greenAccent.withOpacity(0.8)],
        startAngle: -pi / 2 + 2 * pi * riskLevel,
        endAngle: 3 * pi / 2,
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -pi / 2 + 2 * pi * riskLevel,
      2 * pi * (1 - riskLevel),
      false,
      greenPaint,
    );

    // Center label
    final pct = (riskLevel * 100).round();
    final label = riskLevel == 0 ? "100% Safe" : "$pct% Risk";
    final labelColor = riskLevel == 0 ? Colors.greenAccent : Colors.redAccent;
    final tp = TextPainter(
      text: TextSpan(
        text: label,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: labelColor,
          shadows: [Shadow(blurRadius: 2, color: Colors.black45)],
        ),
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant _RiskCirclePainter old) => old.riskLevel != riskLevel;
}
