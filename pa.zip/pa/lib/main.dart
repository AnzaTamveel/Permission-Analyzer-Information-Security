import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:palette_generator/palette_generator.dart';
import 'risk.dart';
import 'dart:math';
import 'main.dart'; // for AppInfo
import 'package:url_launcher/url_launcher.dart';
import 'security_tools.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(PermissionAnalyzerApp());
}

class PermissionAnalyzerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Permission Analyzer',
      theme: ThemeData(
        scaffoldBackgroundColor: Color(0xFF121212), // dark, not black
        cardColor: Color(0xFF1E1E1E), // dark grey
        primaryColor: Colors.blueAccent, // royal blue accent
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFF1E1E1E),
          elevation: 1,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        colorScheme: ColorScheme.dark(
          primary: Colors.blueAccent,
          secondary: Colors.amberAccent, // sassy gold touch
        ),
        textTheme: ThemeData.dark().textTheme.apply(
          bodyColor: Colors.white,
          displayColor: Colors.blueAccent,
        ),
      ),

      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AppInfo {
  final String name;
  final String package;
  final bool isRisky;
  final String iconBase64;
  final List<String> riskyPermissions;

  AppInfo({
    required this.name,
    required this.package,
    this.isRisky = false,
    this.iconBase64 = "",
    this.riskyPermissions = const [],
  });

  factory AppInfo.fromJson(Map data) {
    return AppInfo(
      name: data['name'],
      package: data['package'],
      isRisky: data['isRisky'],
      iconBase64: data['icon'] ?? "",
      riskyPermissions: List<String>.from(data['riskyPermissions'] ?? []),
    );
  }

  // Calculate risk level based on the number of risky permissions
  double get riskLevel {
    // Max of 6 risky permissions
    return (riskyPermissions.length / 6).clamp(0.0, 1.0);
  }
}

const Map<String, Map<String, dynamic>> permissionRiskReasons = {
  'ACCESS_FINE_LOCATION': {
    'reason': 'Allows app to access your precise location. Could be used to track you.',
    'level': 'High'
  },
  'READ_CONTACTS': {
    'reason': 'Allows reading your contacts. Could misuse your private network.',
    'level': 'Medium'
  },
  'CAMERA': {
    'reason': 'Allows app to take photos or videos without consent.',
    'level': 'High'
  },
  'RECORD_AUDIO': {
    'reason': 'Allows app to record audio using microphone.',
    'level': 'High'
  },
  'READ_SMS': {
    'reason': 'Allows reading your text messages, exposing sensitive info.',
    'level': 'High'
  },
  // ➔ You can add more if you want
};




class HomePage extends StatefulWidget {

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with WidgetsBindingObserver {                // ← add this

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);  // ← start observing
    loadApps();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this); // ← stop observing
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Whenever the app comes back into the foreground...
    if (state == AppLifecycleState.resumed) {
      loadApps();     // ← re-query installed apps & permissions
    }
  }

  Future<void> loadApps() async {
    try {
      final result = await platform.invokeMethod('getInstalledApps');
      List<AppInfo> fetched = (result as List)
          .map((e) => AppInfo.fromJson(e))
          .toList();
      setState(() {
        allApps = fetched;
        filteredApps = fetched;
      });
    } catch (e) {
      print("Failed to load apps: $e");
    }
  }

// ... rest of your HomePage build, etc.

  List<AppInfo> allApps = [];
  List<AppInfo> filteredApps = [];
  static const platform = MethodChannel('permission.analyzer/apps');
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Permission Analyzer",
          style: TextStyle(
            color: Colors.grey[400],       // nice subtle grey
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: Color(0xFF1E1E1E),
        elevation: 0,
      ),

    body: _getCurrentTab(),
      bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Color(0xFF1E1E1E),
          selectedItemColor: Colors.blueAccent,
          unselectedItemColor: Colors.grey,
      currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.apps), label: "Apps"),
          BottomNavigationBarItem(icon: Icon(Icons.warning), label: "Risky"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
          BottomNavigationBarItem(icon: Icon(Icons.security), label: "Security"),
        ],
      ),
    );
  }

  Widget _getCurrentTab() {
    if (_currentIndex == 0) return buildAppsPage();
    if (_currentIndex == 1) {
      final riskyApps = allApps.where((a) => a.isRisky).toList();
      return RiskyAppsPage(riskyApps: riskyApps); // ← from risk.dart
    }
    if (_currentIndex == 3) {
      return SecurityToolsPage(allApps: allApps);
    }

    return buildSettingsPage();
  }



  void filterApps(String query) {
    print("Search query: $query");
    setState(() {
      if (query.isEmpty) {
        print("Resetting filteredApps to all apps");
        filteredApps = allApps;
      } else {
        filteredApps = allApps.where((app) {
          final q = query.toLowerCase();
          return app.name.toLowerCase().contains(q) || app.package.toLowerCase().contains(q);
        }).toList();
      }
    });
  }




  Widget buildSettingsPage() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.settings, size: 60, color: Colors.cyanAccent),
          SizedBox(height: 20),
          Text("Theme toggle coming soon!", style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
  Widget buildAppsPage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: TextField(
            onChanged: filterApps,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: "Search apps...",
              hintStyle: TextStyle(color: Colors.white60),
              prefixIcon: Icon(Icons.search, color: Colors.grey[400]),
              filled: true,
              fillColor: Colors.black,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.white12),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.white12),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
              ),
            ),
          ),
        ),

        Expanded(
          child: filteredApps.isEmpty
              ? Center(child: Text("No apps found", style: TextStyle(color: Colors.grey)))
              : ListView.builder(
            itemCount: filteredApps.length,
            padding: EdgeInsets.symmetric(horizontal: 12),
            itemBuilder: (context, index) {
              final app = filteredApps[index];
              return NeonAppCard(app: app);
            },
          ),
        ),
      ],
    );
  }

}





class NeonAppCard extends StatefulWidget {
  final AppInfo app;
  const NeonAppCard({required this.app});

  @override
  _NeonAppCardState createState() => _NeonAppCardState();
}

class _NeonAppCardState extends State<NeonAppCard> with SingleTickerProviderStateMixin {
  Color dominantColor = Colors.black; // fallback
  double _scale = 1.0;

  @override
  void initState() {
    super.initState();
    _extractDominantColor();
  }

  Future<void> _extractDominantColor() async {
    if (widget.app.iconBase64.isNotEmpty) {
      final image = MemoryImage(base64Decode(widget.app.iconBase64));
      final palette = await PaletteGenerator.fromImageProvider(image);
      setState(() {
        dominantColor = palette.dominantColor?.color ?? Colors.cyanAccent;
      });
    }
  }
  void _onTapDown(TapDownDetails details) {
    setState(() {
      _scale = 0.96;
    });
  }

  void _onTapUp(TapUpDetails details) {
    setState(() {
      _scale = 1.0;
    });
  }

  void _onTapCancel() {
    setState(() {
      _scale = 1.0;
    });
  }

  void _openDetailsPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AppDetailPage(app: widget.app)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final iconWidget = widget.app.iconBase64.isNotEmpty
        ? Image.memory(base64Decode(widget.app.iconBase64), width: 50, height: 50)
        : Icon(Icons.android, color: Colors.cyanAccent, size: 40);

    return GestureDetector(
      onTapDown: _onTapDown,
      onTapUp: (details) {
        _onTapUp(details);
        _openDetailsPage(); // <-- OPEN PAGE on tap up!
      },
      onTapCancel: _onTapCancel,
      child: AnimatedScale(
        scale: _scale,
        duration: Duration(milliseconds: 100),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 8,
          margin: EdgeInsets.symmetric(vertical: 10),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: dominantColor.withOpacity(0.6),
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: [
                  dominantColor.withOpacity(0.4),
                  Colors.black.withOpacity(0.9),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: dominantColor.withOpacity(0.6),
                        blurRadius: 12,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: iconWidget,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.app.name,
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                      SizedBox(height: 4),
                      Text(widget.app.package, style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                ),
                Icon(
                  widget.app.isRisky ? Icons.warning_amber_rounded : Icons.verified,
                  color: widget.app.isRisky ? Colors.redAccent : Colors.greenAccent,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
class Breach {
  final String name;
  final String date;
  final String description;

  Breach({required this.name, required this.date, required this.description});

  factory Breach.fromJson(Map<String, dynamic> json) {
    return Breach(
      name: json['Name'] ?? json['Title'] ?? 'Unknown breach',
      date: json['BreachDate'] ?? json['Date'] ?? 'Unknown date',
      description: json['Description'] ?? '',
    );
  }
}

class AppDetailPage extends StatefulWidget {
  final AppInfo app;
  static const _channel = MethodChannel('permission.analyzer/apps');

  const AppDetailPage({required this.app});

  @override
  _AppDetailPageState createState() => _AppDetailPageState();
}

class _AppDetailPageState extends State<AppDetailPage> {
  List<Breach> _breaches = [];
  bool _loadingBreaches = false;

  Future<void> _fetchBreaches() async {
    setState(() => _loadingBreaches = true);

    // This is an example; replace with actual breach search.
    final query = Uri.encodeComponent(widget.app.name);
    final url = Uri.parse('https://haveibeenpwned.com/api/v3/breaches?domain=$query'); // Or adjust URL accordingly
    try {
      final res = await http.get(url, headers: {
        'hibp-api-key': 'YOUR_API_KEY_HERE', // if required
        'Accept': 'application/json',
      });

      print('Response status: ${res.statusCode}');
      if (res.statusCode == 200) {
        final List jsonList = json.decode(res.body);
        if (jsonList.isNotEmpty) {
          _breaches = jsonList.map((j) => Breach.fromJson(j)).toList();
        } else {
          // If no breaches found
          _breaches = [];
        }
      } else {
        print('Failed to fetch breaches: ${res.body}');
      }
    } catch (e) {
      print('Error fetching breaches: $e');
    }

    setState(() => _loadingBreaches = false);
    _showBreachHistory();
  }


  Future<void> _launchGoogleSearch() async {
    final q = Uri.encodeComponent('${widget.app.name} data breach');
    final uri = Uri.parse('https://www.google.com/search?q=$q');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open browser.'))
      );
    }
  }

  void _showBreachHistory() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Color(0xFF1E1E1E),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) {
        if (_loadingBreaches) {
          return Container(
            height: 200,
            alignment: Alignment.center,
            child: CircularProgressIndicator(),
          );
        }
        if (_breaches.isEmpty) {
          return Container(
            padding: EdgeInsets.all(20),
            child: Text(
              'No known breaches found for ${widget.app.name}.',
              style: TextStyle(color: Colors.white),
            ),
          );
        }
        return Container(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Breach History for ${widget.app.name}',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10),
              ..._breaches.map((b) => ListTile(
                title: Text(b.name, style: TextStyle(color: Colors.white)),
                subtitle: Text(b.date, style: TextStyle(color: Colors.grey)),
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: Color(0xFF1E1E1E),
                    title: Text(b.name, style: TextStyle(color: Colors.white)),
                    content: Text(b.description, style: TextStyle(color: Colors.grey)),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text('Close'),
                      )
                    ],
                  ),
                ),
              ))
            ],
          ),
        );
      },
    );
  }

  void _showRiskReason(String permission) {
    String? key = permissionRiskReasons.keys
        .firstWhere((k) => permission.endsWith(k), orElse: () => '');
    final info = permissionRiskReasons[key];
    showModalBottomSheet(
      context: context,
      backgroundColor: Color(0xFF1E1E1E),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Container(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.warning, color: Colors.redAccent, size: 40),
            SizedBox(height: 10),
            Text(permission,
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(info?['reason'] ?? 'No details.', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 20),
            Chip(
              label: Text(info?['level'] ?? 'Unknown',
                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
              backgroundColor: info?['level'] == 'High'
                  ? Colors.redAccent
                  : info?['level'] == 'Medium'
                  ? Colors.amberAccent
                  : Colors.greenAccent,
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final barIcon = widget.app.iconBase64.isNotEmpty
        ? Image.memory(base64Decode(widget.app.iconBase64), width: 32, height: 32)
        : Icon(Icons.android, color: Colors.cyanAccent, size: 32);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF1E1E1E),
        elevation: 0,
        leading: BackButton(color: Colors.grey[400]),
        title: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(6), child: barIcon),
          SizedBox(width: 10),
          Text(widget.app.name, style: TextStyle(color: Colors.grey[400])),
        ]),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(
            child: Icon(widget.app.isRisky ? Icons.warning : Icons.verified,
                size: 50, color: widget.app.isRisky ? Colors.redAccent : Colors.greenAccent),
          ),
          SizedBox(height: 10),
          Center(
            child: Text(
              widget.app.isRisky ? 'Uses risky permissions' : 'Safe permissions',
              style: TextStyle(
                  color: widget.app.isRisky ? Colors.redAccent : Colors.greenAccent,
                  fontSize: 18),
            ),
          ),
          SizedBox(height: 30),
          Center(child: RiskCircularIndicator(riskLevel: widget.app.riskLevel)),
          SizedBox(height: 30),
          if (widget.app.isRisky) ...[
            Text('Risky Permissions',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...widget.app.riskyPermissions.map((p) => ListTile(
              leading: Icon(Icons.warning, color: Colors.redAccent),
              title: Text(p, style: TextStyle(color: Colors.white)),
              onTap: () => _showRiskReason(p),
            )),
            SizedBox(height: 20),
          ],
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            spacing: 12,
            runSpacing: 8,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: widget.app.package));
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text('Copied!')));
                },
                icon: Icon(Icons.copy),
                label: Text('Copy'),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black, foregroundColor: Colors.grey),
              ),
              if (widget.app.isRisky)
                ElevatedButton.icon(
                  onPressed: () =>
                      AppDetailPage._channel.invokeMethod('secureApp', widget.app.package),
                  icon: Icon(Icons.security),
                  label: Text('Secure App'),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black, foregroundColor: Colors.grey),
                ),
              ElevatedButton.icon(
                onPressed: _fetchBreaches,
                icon: Icon(Icons.search),
                label: Text('Check Breach History'),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black, foregroundColor: Colors.grey),
              ),
              TextButton.icon(
                onPressed: _launchGoogleSearch,
                icon: Icon(Icons.web, color: Colors.grey),
                label: Text('Web Search', style: TextStyle(color: Colors.grey)),
              ),
            ],
          )
        ]),
      ),
    );
  }
}


class RiskCircularIndicator extends StatelessWidget {
  final double riskLevel; // 0.0 … 1.0
  const RiskCircularIndicator({required this.riskLevel});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(150, 150),
      painter: _RiskCirclePainter(riskLevel),
    );
  }
}

class _RiskCirclePainter extends CustomPainter {
  final double riskLevel;
  _RiskCirclePainter(this.riskLevel);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width/2, size.height/2);
    final radius = size.width/2;
    const stroke = 8.0;

    // 1) Background circle
    final bgPaint = Paint()
      ..color = Colors.grey.shade800
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    canvas.drawCircle(center, radius, bgPaint);

    // 2) Red “risk” arc
    final redPaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.redAccent.shade700, Colors.redAccent.shade200],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 4); // glow
    final startAngle = -pi/2;
    final redSweep = 2*pi * riskLevel;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      redSweep,
      false,
      redPaint,
    );

    // 3) Green “safe” arc
    final greenPaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.greenAccent.shade700, Colors.greenAccent.shade200],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 4);
    final greenSweep = 2*pi * (1 - riskLevel);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle + redSweep,
      greenSweep,
      false,
      greenPaint,
    );

    // 4) Center label
    String label;
    Color labelColor;
    if (riskLevel == 0) {
      label = "100 % Safe";
      labelColor = Colors.greenAccent;
    } else {
      final pct = (riskLevel * 100).round();
      label = "$pct % Risk";
      labelColor = Colors.redAccent;
    }
    final textStyle = TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.bold,
      color: labelColor,
      shadows: [Shadow(blurRadius: 4, color: Colors.black54, offset: Offset(1,1))],
    );
    final tp = TextPainter(
      text: TextSpan(text: label, style: textStyle),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center - Offset(tp.width/2, tp.height/2));
  }

  @override
  bool shouldRepaint(covariant _RiskCirclePainter old) =>
      old.riskLevel != riskLevel;
}
